﻿ArcMap 10.5客户交付包

先打开START_HERE.html。
数据可直接从Data/Wuhan_Study.gdb和Views导入。
若需要双击工程，交付方先在自己的ArcMap电脑运行一次OPEN_ARCMAP.cmd，生成真正Wuhan_Study.mxd后再把完整目录发客户。云端未生成MXD或LYR，未执行ArcMap打开验证。
